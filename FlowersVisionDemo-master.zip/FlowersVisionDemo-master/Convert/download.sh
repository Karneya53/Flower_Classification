wget https://s3.amazonaws.com/jgoode/oxford102.caffemodel
wget https://github.com/jimgoo/caffe-oxford102/raw/master/AlexNet/deploy.prototxt
